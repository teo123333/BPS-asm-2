import pandas as pd
df = pd.read_excel("testasm2/ASM2_PBI_Exel.xlsx",sheet_name="Sheet1")
pd.set_option('display.max_rows', 100)
#TH filter 
filtering_df = df[df["ProductName"].isin(["Laptop", "Mobile Phone","Digital Camera", "Drone","Smart Lock","Portable Charger","Wireless Charging Pad"])]
print(filtering_df)