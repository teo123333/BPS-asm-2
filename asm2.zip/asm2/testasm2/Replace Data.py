import pandas as pd
df = pd.read_excel("testasm2/ASM2_PBI_Exel.xlsx",sheet_name="Sheet1")
pd.set_option('display.max_rows', 100)
df['Trending Score'] = pd.to_numeric(df['Trending Score'],errors="coerce").fillna(0)
print(df)