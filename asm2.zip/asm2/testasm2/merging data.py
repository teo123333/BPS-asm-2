import pandas as pd
df1 = pd.read_excel("testasm2/ASM2_PBI_Exel.xlsx",sheet_name="Sheet1")
df2 = pd.read_excel("testasm2/ASM2_PBI_Exel2.xlsx",sheet_name="Sheet1")
pd.set_option('display.max_rows', 100)
df = pd.merge(df1,df2,on=['ProductID','ProductName'])
print(df)